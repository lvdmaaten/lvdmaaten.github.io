function coor = line_follow(bw, coor)
%LINE_FOLLOW Performs line following algorithm on contour image
%  
%   coor = line_follow(image)
%   coor = line_follow(image, coor)
%
% Performs a line following algorithm on the binary image bw. The
% background of bw should have values 0, whereas the closed contour in
% image bw should have values 1. The image bw may contain only 1 closed
% contour. The algorithm uses 8-connectivity. The algorithm returns a Nx2
% matrix coor containing the consecutive coordinates of the contour. The
% row vector coor ([y x]) indicates the starting position of the contour. 
% If it is not specified the function will find one for itself.
%
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    % Find beginning location
    if ~exist('coor', 'var')
        coor = [];
        found = 'n';
        x = 1;
        y = 1;
        while found == 'n'
            x = x + 1;
            if x > size(bw, 2)
                x = 1;
                y = y + 1;
                if y > size(bw, 1)
                    return;
                end
            end
            if bw(y, x) == 1
                found = 'y';
            end
        end
    else
        y = coor(1);
        x = coor(2);
    end

    % Create contour
    coor = [];
    if exist('y') & exist('x')
        if bw(y, x + 1)
            coor = bwtraceboundary(bw, [y x], 'E', 8, Inf, 'clockwise');
        elseif bw(y + 1, x)
            coor = bwtraceboundary(bw, [y x], 'S', 8, Inf, 'clockwise');
        elseif bw(y + 1, x + 1)
            coor = bwtraceboundary(bw, [y x], 'SE', 8, Inf, 'clockwise');
        end
    else
        disp('Empty contour!');
        coor = [];
    end
