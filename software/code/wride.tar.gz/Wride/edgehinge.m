function eh = edgehinge(image, frag_length)
%EDGEHINGE Calculates edge-hinge distribution of image
%
%   eh = edgehinge(image, frag_length)
% 
% Calculates edge-hinge distribution from image using the given fragment
% length. The variable frag_length is this fragment length (default = 4).
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    if ~exist('frag_length')
        frag_length = 4;
    end

    % Make sure image is binary
    warning off;
    bw = uint8(im2bw(image));
    [height width] = size(bw);
    
    % Perform edge-hinge detection
    eh = zeros((frag_length - 1) * 8, (frag_length - 1) * 8);
    for x=frag_length+1:width-frag_length-1
        for y=frag_length+1:height-frag_length-1
            if bw(y,x) == 1
                counter = 1;
				found = 'f';
				first = 1;
				for i=0:frag_length-1
					if found == 'f'
						if bw(y-i,x+frag_length) == 1
                            found = 't';
                            first = counter;
                        end
					else
						if bw(y-i,x+frag_length) == 1
                            eh(first, counter) = eh(first, counter) + 1;
                        end 
                    end
					counter = counter + 1;
                end
				for i=frag_length-2:-1:-(frag_length - 1)+1
					if found == 'f'
						if bw(y-frag_length,x-i) == 1
                            found = 't';
                            first = counter;
                        end
                    else
                        if bw(y-frag_length,x-i) == 1
                            eh(first, counter) = eh(first, counter) + 1;
                        end 
                    end
					counter = counter + 1;
                end
				for i=frag_length-1:-1:-(frag_length - 1)+1
					if found == 'f'
						if bw(y-i,x-frag_length) == 1
                            found = 't';
                            first = counter;
                        end
                    else
						if bw(y-i,x-frag_length) == 1
                            eh(first, counter) = eh(first, counter) + 1;
                        end 
                    end
					counter = counter + 1;
                end
				for i=-(frag_length - 1):(frag_length - 2)-1
					if found == 'f'
						if bw(y+frag_length,x+i) == 1
                            found = 't';
                            first = counter;
                        end
                    else
						if bw(y+frag_length,x+i) == 1
                            eh(first, counter) = eh(first, counter) + 1;
                        end 
                    end
					counter = counter+1;
                end
				for i=-(frag_length - 1):0-1
					if found == 'f'
						if bw(y-i,x+frag_length) == 1
                            found = 't';
                            first = counter;
                        end
                    else
						if bw(y-i,x+frag_length) == 1
                            found = 't';
                            eh(first, counter)= eh(first, counter) + 1;
                        end 
                    end
					counter = counter + 1;
                end
            end
        end
    end
    
    % Normalize accumulators
    eh = eh / sum(sum(eh));
