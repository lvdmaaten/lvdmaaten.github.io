WRIDE: a simple system for WRIter IDEntification
================================================


Information
-------------------------
Author: Laurens van der Maaten
Affiliation: MICC-IKAT, Maastricht University, The Netherlands
Contact: l.vandermaaten@micc.unimaas.nl
Release date: June 11th 2007


Brief description
-------------------------
WRIDE is a simple Matlab implementation of a system for writer identification, based on state-of-the-art techniques for writer identification. The system is based on multi-scale edge-hinge features and grapheme features. The grapheme codebook that used in the computatino of grapheme features is constructed by means of a Kohonen SOFM. The classification is performed by a 1-nearest neighbor classifier using Manhattan distance. For detailed information on the system, we refer to:
	
	 - L.J.P. van der Maaten and E.O. Postma. Improving Automatic Writer Identification. In Proceedings of the 17th BNAIC, pages 260-266. Brussels, Belgium, 2005.


Using the system
-------------------------
In order to use the system, please put a set of training images in the Handwritings/train folder and a set of test images in the Handwritings/test folder. Please make sure that the filenames of the training and test files correspond. The system assumes that there is only one training page and one test page available per writer. The system expects the handwriting images to be files with the extension .jpg.
Use the following Matlab commands to use the system:

% ==============================================================
% Extract grapheme features from trainingset
make_grapheme_codebook('Handwritings/train', 100);
save_grapheme_features('Handwritings/train', 100, 'train');

% Extract edge-hinge features from trainingset
save_eh_features('Handwritings/train', [3 5 7 9], 'train');

% Extract all features from testset
save_grapheme_features('Handwritings/test', 100, 'test');
save_eh_features('Handwritings/test', [3 5 7 9], 'test');

% Evaluate the performance of the system
perf = evaluate_performance('Handwritings/train', 100)
% ==============================================================


Contact
-------------------------
If you have any bugs, questions, suggestions, or modifications, please contact me:

	l.vandermaaten@micc.unimaas.nl


