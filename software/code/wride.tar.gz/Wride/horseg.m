function segments = horseg(bw)
%HORSEG Performs horizontal segmentation using the SegM algorithm
%
%   segments = horseg(image)
%
% Performs horizontal segmentation y-minima and empty vertical runs. The 
% variable is an image containing one line of text.
% The matrix segments is an 1xN containing the N found segments.
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    % Check input
    if ~islogical(bw)
        bw = im2bw(bw);
    end

    % Initialize variables
    segments = 1;

    % Create 1-pixel border
    bw = padarray(bw, [1 1], 1, 'both');
    
    % Create vertical run-length vector
    runlengths = ones(1, size(bw, 2)) * size(bw, 1);
    [r, c] = find(bw == 0);
    for i=1:size(bw, 2)
        tmp = max(r(c == i));
        if ~isempty(tmp)
            runlengths(i) = tmp;
        end
    end
    
    % Search for local minima in run-length vector (check neighbouring 6 pixels)
    for i=4:length(runlengths) - 3
        if runlengths(i) > runlengths(i - 1)
            if runlengths(i - 1) >= runlengths(i - 2)
                if runlengths(i) >= runlengths(i + 1)
                    if runlengths(i + 1) >= runlengths(i + 2)
                        segments = [segments i];
                    end
                end
            end
        end
        if runlengths(i) == size(bw, 2)
            segments = [segments i];
        end
    end
