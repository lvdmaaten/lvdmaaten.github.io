function distance = pdfdist(x, y, type)
%PDFDIST Calculates distance between vectors using various distance types
%
%   distance = pdfdist(x, y);
%   distance = pdfdist(x, y, type);
%
% Calculates the distance between two row vectors x and y. Variable type specifies
% the used distance type, and may have the following values (default = 'eucl'):
%   - 'manh' - Manhattan distance
%   - 'eucl' - Euclidian distance
%   - 'chis' - Chi-square distance
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2005

    if exist('type') == 0
        type = 'eucl';
    end

    if strcmp(type, 'manh')   
        distance = sum(abs(x - y));
    elseif strcmp(type, 'eucl') 
        distance = sqrt(sum((x - y) .^ 2));
    elseif strcmp(type, 'chis') 
        distance = sum(((x - ((x + y) ./ 2)) .^ 2) / ((x + y) ./ 2));
    end
            

