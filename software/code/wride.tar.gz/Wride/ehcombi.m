function eh = ehcombi(filename, frag_length)
%EHCOMBI Computes edge-hinge combination for number of fragment lengths.
%
%   eh = ehcombi(filename, frag_lengths)
% 
% Calculates edge-hinge distribution from the image specified by filename,
% using the given fragment lengths. Both eh and frag_length are row vectors.
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    % Read image
    image = imread(filename);
    
%     % Extract ROI (Firemaker only!)
%     toprow = 704;
%     bottomrow = 3212;
%     leftcolumn = 44;
%     rightcolumn = 2442;
%     image = image(toprow:bottomrow,leftcolumn:rightcolumn);

    % Sobel convolution
    image = edge(image, 'sobel');

    % Compute EH combinations
    eh = [];
    for i=1:size(frag_length, 2)
        temp = edgehinge(image, frag_length(i));
        eh = [eh temp(1:end)];
    end