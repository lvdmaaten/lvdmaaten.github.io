function make_grapheme_codebook(folder, s)
%MAKE_GRAPHEME_CODEBOOK Makes a grapheme codebook of size s
%
%   make_grapheme_codebook(folder, s)
%
% The function makes of grapheme codebook of size s (default = 100). It
% does so by extracting graphemes from all images in the folder indicated
% by folder.
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    if ~exist('s', 'var')
        s = 100;
    end

    % Extracting graphemes from handwritings in folder train
    disp('Getting file list...');
    files = dir([folder '/*.jpg']);
    graphemes = [];
    for i=1:length(files)
        disp(['Extracting graphemes from ' files(i).name '...']);
        graphemes = [graphemes; extract_graphemes([folder '/' files(i).name])];
    end
    
    % Construct grapheme codebook
    disp('Training SOFM...');
    dims = [ones(50,1) * -25 ones(50,1) * 25];
    codebook = newsom(dims, s);
    codebook.trainParam.epochs = 100;
    codebook = train(codebook, graphemes');
    clear graphemes;
    save(['Codebooks/codebook_' num2str(s) '.mat'], 'codebook');
    