function save_grapheme_features(folder, s, type)
%SAVE_FEATURES Extracts and saves grapheme features
%
%   save_grapheme_features(folder, s, type)
%
% This function extracts and saves grapheme features from handwriting images.
% The variable folder contains the image directory. The variable s contains
% the size of the codebook to use (default = 100). The function extracts 
% grapheme features from all image files and saves them into a file.
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    if ~exist('s', 'var')
        s = 100;
    end
    
    % Load codebook
    load(['Codebooks/codebook_' num2str(s) '.mat']);

    % Extract features from image files in folder
    disp('Getting file list...');
    files = dir([folder '/*.jpg']);
    accum = zeros(length(files), s);
    labels = zeros(length(files), 1);
    for i=1:length(files)
        disp(['Processing file ' num2str(i) ' from '  num2str(length(files)) '...']);
        graph = extract_graphemes([folder '/' files(i).name]);
        disp(['Extracted ' num2str(size(graph, 1)) ' graphemes...']);
        
        % Accumulate
        for j=1:size(graph, 1)
            node = sim(codebook, (graph(j,:))');
            pos = find(full(node) == 1);
            accum(i, pos) = accum(i, pos) + 1;
        end
        labels(i) = i;
        disp('Accumulation complete.');
    end
    
    % Normalize accumulator
    accumsum = sum(accum, 2);
    for i=1:size(accum, 1)
        accum(i,:) = accum(i,:) / accumsum(i);
    end
    
    % Save accumulators
    save(['Accumulators/accum_' num2str(s) '_' type '.mat'], 'accum', 'labels');
    