function segments = linesegment(image)
%LINESEGMENT Performs line segmentation on a handwriting image
%
%   segments = linesegment(image);
%
% Performs line segmentation on a handwriting image. The variable image is
% the image to process, and segments is an 1x(2xR) row vector, containing 
% the R found segments.
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    % Check input
    if ~islogical(image)
        image = im2bw(image);
    end

    % Initialize variables
    [height width] = size(image);
    segments = [];
	newSegment = 'f';
    
    % From top to bottom
    for y=1:height
        % Count number of black pixels in horizontal run
		counter = length(find(image(y,:) == 0));
        clear find;
        
        % Compute black pixel ratio
		ratio = counter / width;
        
        % If ratio to high, start new segment
		if ratio > 0.075 && newSegment == 'f'
			newSegment = 't';
            yvalue = y - 25;
            if yvalue < 1
                yvalue = 1;
            end
			segments = [segments yvalue];
        
        % If ratio to low, stop current segment
        elseif ratio < 0.075 && newSegment == 't'
			newSegment = 'f';
            yvalue = y + 25;
            if yvalue > height
                yvalue = height;
            end
			segments = [segments yvalue];
        end
    end
    
    % Close last line segment
	if newSegment == 't'
        segments = [segments (height - 1)];
    end
