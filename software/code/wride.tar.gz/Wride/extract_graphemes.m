function graphemes = extract_graphemes(filename)
%EXTRACT_GRAPHEMES Extract graphemes from a handwriting image in a 2D representation
%
%   graphemes = extract_graphemes(filename)
%
% Extracts all graphemes from a handwriting image. FILE indicates the file
% from which the graphemes should be extracted. The variable grapheme_level
% indicates the level for leveled grapheme features (default = 1).
% The function returns a Nx100 matrix, containing N graphemes, encoded as 2D 
% contour signals, which are resampled to a length of 50.
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    warning off
    grapheme_level = 1;

    % Read image
    bw_all = imread(filename);
    
%     % Extract ROI (Firemaker only!)
%     toprow = 704;
%     bottomrow = 3212;
%     leftcolumn = 44;
%     rightcolumn = 2442;
%     bw_all = bw_all(toprow:bottomrow,leftcolumn:rightcolumn);
    
    % Perform line segmentation
    if ~strcmp(class(bw_all), 'logical')
        bw_all = im2bw(bw_all);
    end
    segments = linesegment(bw_all);
    no_seg = size(segments, 2);
    
    % Do for all lines
    graphemes = [];
    kernel = [-1 -1 -1; -1 8 -1; -1 -1 -1];
    for i=1:2:no_seg
        
        % Only if line is larger than 15 pixels (ignore non-lines)
        if (segments(1, i + 1) - segments(1, i)) > 20
            
            % Store current line in bw
            bw = bw_all(segments(1, i):segments(1, i+1),:);

            % Create segmentation blobs (horizontal segmentation)
            [m n] = size(bw);
            segs = horseg(bw);
            [k l] = size(segs);
            
            % For all grapheme segments (take into account GRAPHEME_LEVEL)
            for j=1 + grapheme_level:grapheme_level:l
                
                % Only if horizontal segment > 2 pixels
                if((segs(1, j) - segs(1, j - grapheme_level)) > 2)
                    
                    % Store grapheme segment in seg
                    seg = bw(1:m - 1,segs(1, j - grapheme_level):segs(1, j));

                    if size(seg, 2) > 5
                        % Create 3-pixel border
                        seg = padarray(seg, [3 3], 1, 'both');

                        % Find graphemes
                        seg = im2bw(conv2(uint8(seg), kernel), 0.5);
                        seg = seg(3:size(seg, 1) - 2, 3:size(seg, 2) - 2);
                        contour = 0;
                        while ~isempty(contour)
                            % Find contour
                            contour = line_follow(seg);
                                                    
                            if ~isempty(contour)
                                % Remove segment
                                seg(contour(:,1), contour(:,2)) = 0;
                                
                                % Normalize contour coordinates
                                contour(:,1) = contour(:,1) - min(contour(:,1)) + 1;
                                contour(:,2) = contour(:,2) - min(contour(:,2)) + 1;

                                % Center contour coordinates around O
                                contour(:,1) = contour(:,1) - round(max(contour(:,1)) / 2);
                                contour(:,2) = contour(:,2) - round(max(contour(:,2)) / 2);
              
                                % Resample coordinates to length 50 and store
                                contour = resample(contour, 25, size(contour, 1));                                
                                graphemes = [graphemes; contour(1:end)];
                            end
                        end
                    end
                end
            end
        end
    end


      