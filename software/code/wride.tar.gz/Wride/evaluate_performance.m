function performance = evaluate_performance(folder, grapheme_sizes)
%EVALUATE_PERFORMANCE Evaluate performance of edge-hinge and grapheme features
%
%   performance = evaluate_performance(folder, grapheme_sizes)
%
% The function evaluates the performance of stored edge-hinge and grapheme
% features. The function uses feature vectors based on a combination of
% edge-hinge features and grapheme features. The grapheme features are can 
% be specified by grapheme_sizes (defualt = [100]). Note that the
% corresponding accumulator files should exist in order to successfully
% perform this function!
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    if ~exist('grapheme_sizes', 'var')
        grapheme_sizes = 100;
    end
    
    % Initialize variables
    gr1 = []; 
    gr2 = [];
    files = dir([folder '/*.jpg']);
    
    % Load edge hinge train features
    load(['Accumulators/edge_hinge_train.mat']);
    eh1 = FEAT_VEC2;

    % Load edge hinge test features
    load(['Accumulators/edge_hinge_test.mat']);
    eh2 = FEAT_VEC2;
      
    % Load grapheme features
    for i=grapheme_sizes
        load(['Accumulators/accum_' num2str(i) '_train.mat']);
        gr1 = [gr1 accum];
        load(['Accumulators/accum_' num2str(i) '_test.mat']);
        gr2 = [gr2 accum];
    end

    % Create labels
    for i=1:size(gr1, 1)
        lab{i} = num2str(i);
    end

    % Combine MSEH features and grapheme features
    if numel(gr1) > 0 & numel(eh1) > 0
        weight = sum(sum(gr1)) / sum(sum(eh1));
    else
        weight = 1;
    end
    train = [gr1 weight * eh1];
    test = [gr2 weight * eh2];

    % Measure identification performance
    score = 0;
    for i=1:size(test, 1)
        mindist = Inf;
        for h=1:size(train, 1)
            dist = pdfdist(train(h,:), test(i,:), 'manh');
            if dist < mindist
                mindist = dist;
                index = h;
            end
        end
        if i == index
            score = score + 1;
        end
        disp(['Instance with label ' files(i).name ' labeled as ' files(index).name '...']);
    end
    performance = score / size(test, 1);
