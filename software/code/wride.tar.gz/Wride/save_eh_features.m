function save_eh_features(folder, sizes, type)
%SAVE_EH_FEATURES Extracts and saves edge-hinge features
%
%   save_eh_features(folder, sizes, type)
%
% This function extracts and saves edge-hinge features from handwriting images.
% The variable folder contains the image directory. The variable size contains
% the fragment lengths to use (default = [3 5 7 9]). The function extracts 
% grapheme features from all image files and saves them into a file. The
% variable type should be 'train' or 'test' to indicate whether we are
% dealing with training or test data (default = 'train').
% 
%
% (C) Laurens van der Maaten
% Universiteit Maastricht, 2007

    if ~exist('sizes', 'var')
        sizes = [3 5 7 9];
    end
    if ~exist('type', 'var')
        type = 'train';
    end
    
    % Extract features from image files in folder
    disp('Getting file list...');
    files = dir([folder '/*.jpg']);
    tmp = ehcombi([folder '/' files(1).name], sizes);
    FEAT_VEC2 = zeros(length(files), size(tmp, 2));
    labels = zeros(length(files), 1);
    for i=1:length(files)
        disp(['Processing file ' num2str(i) ' from '  num2str(length(files)) '...']);
        FEAT_VEC2(i,:) = ehcombi([folder '/' files(i).name], sizes);
        labels(i) = i;
    end
   
    % Save features
    save(['Accumulators/edge_hinge_' type '.mat'], 'FEAT_VEC2', 'labels');
    