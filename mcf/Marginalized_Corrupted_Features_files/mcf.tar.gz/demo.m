% Copyright (c) 2013, Laurens van der Maaten (Delft University of Technology), 
% Minmin Chen, Stephen Tyree, and Kilian Weinberger (Washington University in St. Louis)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 1. Redistributions of source code must retain the above copyright
%    notice, this list of conditions and the following disclaimer.
% 2. Redistributions in binary form must reproduce the above copyright
%    notice, this list of conditions and the following disclaimer in the
%    documentation and/or other materials provided with the distribution.
% 3. All advertising materials mentioning features or use of this software
%    must display the following acknowledgement:
%    This product includes software developed by the Delft University of 
%    Technology and Washington University in St. Louis.
% 4. Neither the name of the Delft University of Technology and Washington 
%    University in St. Louis nor the names of its contributors may be used 
%    to endorse or promote products derived from this software without 
%    specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY LAURENS VAN DER MAATEN, MINMIN CHEN, STEPHEN 
% TYREE, AND KILIAN WEINBERGER ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
% FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL LAURENS 
% VAN DER MAATEN, MINMIN CHEN, STEPHEN TYREE, AND KILIAN WEINBERGER BE LIABLE 
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
% USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.



    clear all
    close all

    % Set corruption level of test data
    noise = .5;
    
    % Set loss function to minimize
    loss = 'qua';

    % Load a small data set
    disp('Loading version of MNIST data set with 5,000 training points...');
    load 'data/small_mnist_train.mat'
    load 'data/small_mnist_test.mat'
    
    % Apply corruptions to test data
    disp(['Randomly deleting ' num2str(noise * 100) '% of the features in the test data...']);
    test_X(rand(size(test_X)) < noise) = 0;
    
    % Show examples of training and test data
    disp('Showing examples...');
    no_examples = 5;
    figure(1);
    for i=1:no_examples
        if i == ceil(no_examples ./ 2), show_title = true; else show_title = false; end
        subplot(2, no_examples, i);               imagesc(reshape(train_X(:,i), [28 28])'); colormap gray; axis equal tight off; if show_title, title('Training images'); end
        subplot(2, no_examples, i + no_examples); imagesc(reshape( test_X(:,i), [28 28])'); colormap gray; axis equal tight off; if show_title, title('Test images'); end
    end
    drawnow
    
    % Train two models with quadratic loss
    lambda = 0;
    q = 0:.1:.9;
    test_err = nan(1, length(q));
    for i=1:length(q)
        disp(['Training model ' num2str(i) ' of ' num2str(length(q)) '...']);
        fh = str2func(['mcf_blankout_' loss]);
        [~, ~, test_err(i)] = fh(train_X, train_labels, q(i), lambda, test_X, test_labels); toc
    end
    
    % Plot results
    figure(2); plot(q, test_err);
    xlabel('MCF-Blankout Level q');
    ylabel('Test Classification Error');
    title('Nightmare at Test Time', 'FontWeight', 'bold');
    set(gca, 'YLim', [0 .5]);  
    drawnow    
    