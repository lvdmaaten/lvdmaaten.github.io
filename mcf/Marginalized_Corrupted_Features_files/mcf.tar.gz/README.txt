
INTRODUCTION
============
Marginalized Corrupted Features (MCF) is a new approach to combatting overfitting in supervised learning. The key idea behind MCF is that you can regularize models by training them on corrupted copies of the data. MCF corrupts the data according to a pre-specified corrupting distribution. It trains linear models on infinitely many samples drawn from this corrupting distribution, without increasing the computational complexity.

For more details on MCF, please refer to the following paper:
??? L.J.P. van der Maaten, M. Chen, S. Tyree, and K.Q. Weinberger. Learning with Marginalized Corrupted Features. In Proceedings of the International Conference on Machine Learning (ICML), JMLR W&CP 28:410-418, 2013.

Please cite our work when you use our software!



PACKAGE DESCRIPTION
===================
This package contains MCF code for three loss functions (quadratic, exponential, and logistic) and three corrupting distributions (blankout / dropout, Gaussian corruption, and Poisson corruption).

The functions required to train a MCF model on a data set follow the following naming convention: 

	>> mcf_<corruption>_<loss>

Herein, <corruption> is one of three options: blankout, poisson, or gaussian; and <loss> is one of three options: qua, exp, or log. The code can also be used with sparse data sets. If you want to use sparse data with MCF, please perform the following commands in Matlab first:

    >> cd sparse, make, cd ..

Please consult the script demo.m for a demonstration of the use of MCF (in the "nightmare at test time" setting).



DEPENDENCIES
============
This code uses the minFunc package by Mark Schmidt. A version of minFunc is included in this package. For more information on minFunc, please consult: http://www.di.ens.fr/~mschmidt/Software/minFunc.html



LICENSE
=======
This software is licensed under a BSD license. See the included LICENSE file for details.


