function [W, train_err, test_err] = mcf_blankout_exp(X, Y, p, lambda, test_X, test_Y)
%MCF_BLANKOUT_EXP Trains a denoising classifier using exponential loss
%
%   [W, train_err, test_err] = mcf_blankout_exp(X, Y, p, lambda, test_X, test_Y)
%
% The function trains an MCF classifier with noise level p using exponential
% loss. The resulting classifier weights are returned in W, as well as the
% corresponding training and test errors.


% Copyright (c) 2013, Laurens van der Maaten (Delft University of Technology), 
% Minmin Chen, Stephen Tyree, and Kilian Weinberger (Washington University in St. Louis)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 1. Redistributions of source code must retain the above copyright
%    notice, this list of conditions and the following disclaimer.
% 2. Redistributions in binary form must reproduce the above copyright
%    notice, this list of conditions and the following disclaimer in the
%    documentation and/or other materials provided with the distribution.
% 3. All advertising materials mentioning features or use of this software
%    must display the following acknowledgement:
%    This product includes software developed by the Delft University of 
%    Technology and Washington University in St. Louis.
% 4. Neither the name of the Delft University of Technology and Washington 
%    University in St. Louis nor the names of its contributors may be used 
%    to endorse or promote products derived from this software without 
%    specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY LAURENS VAN DER MAATEN, MINMIN CHEN, STEPHEN 
% TYREE, AND KILIAN WEINBERGER ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
% FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL LAURENS 
% VAN DER MAATEN, MINMIN CHEN, STEPHEN TYREE, AND KILIAN WEINBERGER BE LIABLE 
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
% USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


    if ~exist('p', 'var') || isempty(p)
        p = 0;
    end
    if ~exist('lambda', 'var') || isempty(lambda)
        lambda = 0;
    end
    assert(size(X, 2) == size(Y, 2));
    addpath(genpath('minFunc'));
    
    % Construct label matrix
    [D, N] = size(X);
    if size(Y, 1) == 1
        [lablist, ~, labels] = unique(Y);
        K = numel(lablist);
        Y = -ones(K, N) .* (1 ./ (K - 1));
        Y(sub2ind([K N], labels, (1:N))) = 1;
        if exist('test_Y', 'var') && ~isempty(test_Y)
            test_labels = test_Y;
            test_Y = -ones(K, size(test_X, 2)) .* (1 ./ (K - 1));
            for i=1:size(test_X, 2)
                test_Y(find(lablist == test_labels(i), 1, 'first'), i) = 1;
            end
        end
    end
    
    % Initialize some variables
    W = randn(K, D + 1) * .001;    
    X = [X; ones(1, N)];
    if exist('test_X', 'var') && ~isempty(test_X)
        test_X = [test_X; ones(1, size(test_X, 2))];
    end
    
    % Train classifier
    options.Method = 'lbfgs';
    options.Display = 'on';
    options.TolFun = 1e-7;
    options.TolX = 1e-7;
    options.MaxIter = 200;
    if issparse(X)
        addpath('sparse');
        setenv('OMP_NUM_THREADS', '4');
        W = reshape(minFunc(@exp_loss_grad, W(:), options, X, Y, @(W,X,Y)exp_loss_grad_blankout(W,X,Y,p), lambda), [K D + 1]);
    else
        W = reshape(minFunc(@mcf_blankout_exp_grad, W(:), options, X, Y, p, lambda), [K D + 1]);
    end
    
    % Evaluate classifier on training data
    [~, true_Y] = max(Y,     [], 1);
    [~, pred_Y] = max(W * X, [], 1);
    train_err = sum(pred_Y ~= true_Y) ./ numel(true_Y);
    disp(['Training error: ' num2str(train_err)]);
        
    % Evaluate classifier on test data
    if exist('test_X', 'var') && exist('test_Y', 'var') && ~isempty(test_X) && ~isempty(test_Y)
        [~, true_Y] = max(test_Y, [], 1);
        [~, pred_Y] = max(W * test_X, [], 1);
        test_err = sum(pred_Y ~= true_Y) ./ numel(true_Y);
        disp(['Test error: ' num2str(test_err)]);
    end    
    