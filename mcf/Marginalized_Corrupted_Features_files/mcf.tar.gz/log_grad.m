function [C, dC] = log_grad(W, X, Y, lambda)
%LOG_GRAD Gradient of logistic loss
%
%   [C, dC] = log_grad(W, X, Y, lambda)
%
% The function computes the logistic loss and the corresponding gradient 
% for weight vector W.


% Copyright (c) 2013, Laurens van der Maaten (Delft University of Technology), 
% Minmin Chen, Stephen Tyree, and Kilian Weinberger (Washington University in St. Louis)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 1. Redistributions of source code must retain the above copyright
%    notice, this list of conditions and the following disclaimer.
% 2. Redistributions in binary form must reproduce the above copyright
%    notice, this list of conditions and the following disclaimer in the
%    documentation and/or other materials provided with the distribution.
% 3. All advertising materials mentioning features or use of this software
%    must display the following acknowledgement:
%    This product includes software developed by the Delft University of 
%    Technology and Washington University in St. Louis.
% 4. Neither the name of the Delft University of Technology and Washington 
%    University in St. Louis nor the names of its contributors may be used 
%    to endorse or promote products derived from this software without 
%    specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY LAURENS VAN DER MAATEN, MINMIN CHEN, STEPHEN 
% TYREE, AND KILIAN WEINBERGER ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
% FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL LAURENS 
% VAN DER MAATEN, MINMIN CHEN, STEPHEN TYREE, AND KILIAN WEINBERGER BE LIABLE 
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
% USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


    % Decode solution
    D = size(X, 1);
    K = size(Y, 1);
    W = reshape(W, [K D]);
    
    % Compute p(y|x)
    gamma = W * X;
    gamma = exp(bsxfun(@minus, gamma, max(gamma, [], 1)));
    gamma = bsxfun(@rdivide, gamma, max(sum(gamma, 1), realmin));
    
    % Compute conditional log-likelihood
    C = 0;
    for k=1:K
        C = C - sum(log(max(gamma(k, Y(k,:) == 1), realmin)));
    end
    if lambda > 0    
        C = C + lambda .* sum(sum(W(:,1:end - 1) .^ 2));
    end
    
    % Only compute gradient when required
    if nargout > 1
        dC = gamma * X';
        for k=1:K
            dC(k,:) = dC(k,:) - sum(X(:,Y(k,:) == 1), 2)';
        end
        if lambda > 0    
            dC(:,1:end - 1) = dC(:,1:end - 1) + 2 .* lambda .* W(:,1:end - 1);
        end
        dC = dC(:);
    end
    