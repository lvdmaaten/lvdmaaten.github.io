/*
 *
Copyright (c) 2013, Laurens van der Maaten (Delft University of Technology), 
Minmin Chen, Stephen Tyree, and Kilian Weinberger (Washington University in St. Louis)
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:
   This product includes software developed by the Delft University of 
   Technology and Washington University in St. Louis.
4. Neither the name of the Delft University of Technology and Washington 
   University in St. Louis nor the names of its contributors may be used 
   to endorse or promote products derived from this software without 
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY LAURENS VAN DER MAATEN, MINMIN CHEN, STEPHEN 
TYREE, AND KILIAN WEINBERGER ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL LAURENS 
VAN DER MAATEN, MINMIN CHEN, STEPHEN TYREE, AND KILIAN WEINBERGER BE LIABLE 
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **/


#include <math.h>
#include "mex.h"
#include <string.h>
#include <omp.h>
#include <float.h>

#define inW 0
#define inX 1
#define inY 2
#define inP 3

#define outprod 0
#define outdC 1

inline double dot(double *x, double *y, int n) {
	double result = 0.;
	for (int i=0; i<n; i++)
		result += x[i]*y[i];
	return result;
}

inline int numParams();

inline void mgfAndGradDivY(
	double param, double *y_n, double *w_d, int K, double x_nd, 
	double &mgf_nd, double &mgf_grad_nd_div_y, bool computeGradient);
	// assumes mgf_nd(x_nd=0) = 1
	// assume mgf_grad_nd_div_y(x_nd=0) = 0
	// assumes mgf_grad_nd = y_n * mgf_grad_nd_div_y

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* Declare Variables */
    double *w, *y, *x, *C;
	double *dC = NULL;
	double *prods = NULL;
	double param;
	mwIndex *xir, *xjc, *dCir, *dCjc;
	int N, D, K, nzmax;
	bool computeGradient, returnProds;
	
	/* Verify number of inputs and outputs */
	if (nrhs < 3 or nrhs > 4) mexErrMsgTxt("Requires 3 or 4 arguments: W, Y, X [, param]");
	if (nlhs > 2) mexErrMsgTxt("Produces at most two outputs: prod, dCdivY");
	
    /* Get D, N, K */
    D = mxGetN(prhs[inW]);
    N = mxGetN(prhs[inY]);
	K = mxGetM(prhs[inY]);
	nzmax = mxGetNzmax(prhs[inX]);
	
	/* How many outputs? */
	computeGradient = (nlhs > 1);
	
	/* Verify Input Types and Dimensions */
	if (!mxIsDouble(prhs[inW]) or !mxIsDouble(prhs[inY]) or !mxIsDouble(prhs[inX]))
		mexErrMsgTxt("Inputs must be of type double");
	if (!mxIsSparse(prhs[inX]))
		mexErrMsgTxt("X must be a sparse matrix");
	if (D != mxGetM(prhs[inX]))
		mexErrMsgTxt("The dimensionality of W and X must match, size(W,1)==size(X,1)");
	if (N != mxGetN(prhs[inX]))
		mexErrMsgTxt("The number of instances in X and Y must match, size(X,2)==size(Y,2)");
	if (K != mxGetM(prhs[inW]))
		mexErrMsgTxt("The number of classes in W and Y must match, size(W,2)==size(Y,1)");
	
	/* Define Input Pointers */
    w = mxGetPr(prhs[inW]); // KxD matrix
    y = mxGetPr(prhs[inY]); // KxN matrix
    
	if (nrhs > 3) {
		if (nrhs-3 != numParams()) mexErrMsgTxt("Unused parameter supplied"); 
		param = mxGetPr(prhs[inP])[0]; // scalar
	} else {
		if (0 != numParams()) mexErrMsgTxt("Missing parameter"); 
		param = -999999999.;
	}
	
	x = mxGetPr(prhs[inX]); // DxN sparse matrix
	xir = mxGetIr(prhs[inX]);
	xjc = mxGetJc(prhs[inX]);
    
	/* Allocate Memory for Outputs */
	plhs[outprod] = mxCreateDoubleMatrix(1,N,mxREAL); // 1xN row vector
	prods = mxGetPr(plhs[outprod]);
	
	if (computeGradient) {
		plhs[outdC] = mxCreateSparse(D, N, nzmax, mxREAL); // DxN sparse matrix
		dC = mxGetPr(plhs[outdC]);
		dCir = mxGetIr(plhs[outdC]);
		for (int i=0; i<nzmax; i++) dCir[i] = xir[i];
		dCjc = mxGetJc(plhs[outdC]);
		for (int i=0; i<N+1; i++) dCjc[i] = xjc[i];
	}
	
	/* Compute */
	double *b = &w[(D-1)*K];
	#pragma omp parallel for default(shared)
	for (int j=0; j<N; j++) { // column of x
		mwIndex rowstart = xjc[j];
		mwIndex rowend = xjc[j+1];
		double *y_j = &y[j*K]; // jth column of y
		
		double prod_mgf_j = 1.0;
		for (mwIndex k = rowstart; k<rowend-1; k++) { // sparse index of x(i,j)
			mwIndex i = xir[k]; // row of x
			double x_ij = x[k]; // x_ij
			double *w_i = &w[i*K]; // ith row of w'
			
			double mgf_ij, mgf_grad_ij_div_y;
			mgfAndGradDivY(param, y_j, w_i, K, x_ij, mgf_ij, mgf_grad_ij_div_y, computeGradient);
			
			prod_mgf_j *= mgf_ij;
			if (computeGradient) dC[k] = mgf_grad_ij_div_y / (mgf_ij + FLT_MIN);
		}
		
		double yj_dot_b = dot(y_j, b, K); // bias has no noise
		prod_mgf_j *= exp(-yj_dot_b);
		if (computeGradient) dC[rowend-1] = -1.0;
		
		prods[j] = prod_mgf_j;
		
		if (computeGradient)
			for (mwIndex k = rowstart; k<rowend; k++) dC[k] *= prod_mgf_j;
	}
}
