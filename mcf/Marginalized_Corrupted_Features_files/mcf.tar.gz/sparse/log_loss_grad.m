% Copyright (c) 2013, Laurens van der Maaten (Delft University of Technology), 
% Minmin Chen, Stephen Tyree, and Kilian Weinberger (Washington University in St. Louis)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 1. Redistributions of source code must retain the above copyright
%    notice, this list of conditions and the following disclaimer.
% 2. Redistributions in binary form must reproduce the above copyright
%    notice, this list of conditions and the following disclaimer in the
%    documentation and/or other materials provided with the distribution.
% 3. All advertising materials mentioning features or use of this software
%    must display the following acknowledgement:
%    This product includes software developed by the Delft University of 
%    Technology and Washington University in St. Louis.
% 4. Neither the name of the Delft University of Technology and Washington 
%    University in St. Louis nor the names of its contributors may be used 
%    to endorse or promote products derived from this software without 
%    specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY LAURENS VAN DER MAATEN, MINMIN CHEN, STEPHEN 
% TYREE, AND KILIAN WEINBERGER ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
% INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
% FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL LAURENS 
% VAN DER MAATEN, MINMIN CHEN, STEPHEN TYREE, AND KILIAN WEINBERGER BE LIABLE 
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
% USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


function [C, dC] = log_loss_grad(W, X, Y, exp_loss_grad_mgf, lambda, L2)
	

    if ~exist('L2', 'var') || isempty(L2)
        L2 = true;
    end

	% Decode solution
    [D, N] = size(X);
    K = size(Y, 1);
    W = reshape(W, [K D]);
    
    % Compute expected product of MGF and gradient/Y
    prodM = nan(K, N);
    dC_divY = nan(D, N, K);
    for k=1:K
        Yk = zeros(K, N); Yk(k,:) = 1;        
        if nargout > 1
            [prodM(k,:), dC_divY(:,:,k)] = exp_loss_grad_mgf(-W, X, Yk);
        else
            prodM(k,:) = exp_loss_grad_mgf(-W, X, Yk);
        end
    end
%     
%     if any(isnan(prodM(:)))
%         warning('Nan in prodM!');
%     end
%     if any(isinf(prodM(:)))
%         warning('Inf in prodM!');
%     end
%     if any(isnan(dC_divY(:)))
%         warning('Nan in dC_divY!');
%     end
%     if any(isinf(dC_divY(:)))
%         warning('Inf in dC_divY!');        
%     end
%     if any(isnan(prodM(:))) || any(isinf(prodM(:))) || any(isnan(dC_divY(:))) || any(isinf(dC_divY(:)))
%         save 'tmp.mat'
%         pause
%     end
    
    % Compute the loss function and regularize
    tmp_W = W';
    [~, lab] = max(Y, [], 1);
    f = functions(exp_loss_grad_mgf);
    noise_model = f.function;
    if ~isempty(strfind(noise_model, 'exp_loss_grad_blankout'))
        p = f.workspace{1}.p;
        q = repmat(p, [D 1]); q(end) = 0;
        C = -sum(sum(tmp_W(:,lab) .* bsxfun(@times, 1 - q, X), 1));
    else
        C = -sum(sum(tmp_W(:,lab) .* X, 1));
    end
    C = C + sum(log(sum(prodM, 1)));
    C = C ./ N;
    if L2
        C = C + lambda .* sum(sum(W(:,1:end - 1) .^ 2));
    else
        C = C + lambda .* sum(sum(abs(W(:,1:end - 1))));
    end
	
    % Compute gradient (if requested)
    if nargout > 1
        if ~isempty(strfind(noise_model, 'exp_loss_grad_blankout'))
            dC = -Y * bsxfun(@times, (1 - q), X)';
        else
            dC = -(Y * X');
        end 
        Yk = 1 ./ max(sum(prodM, 1), realmin);
        for k=1:K
            dC(k,:) = dC(k,:) - Yk * dC_divY(:,:,k)';
        end
        dC = dC ./ N;
        if L2
            dC(:,1:end - 1) = dC(:,1:end - 1) + 2 .* lambda .* W(:,1:end - 1);
        else
            dC(:,1:end - 1) = dC(:,1:end - 1) + lambda .* sign(W(:,1:end - 1));
        end
        dC = dC(:);
    end
